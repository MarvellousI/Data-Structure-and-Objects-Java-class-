package weekTen.labTen;

public class Mage extends Character implements Fighter {
    private int magicPower;

    public Mage(int health, int attackPower, int defense, int magicPower, String name) {
        super(health, attackPower, defense, name);
        this.magicPower = magicPower;
    }

    @Override
    public void attack(Character opponent) {
        int damage = getAttackPower() + magicPower - opponent.getDefense();
        opponent.setHealth(opponent.getHealth() - (damage > 0 ? damage : 0));
        System.out.println("Mage " + getName() + " casts a spell! Opponent's health: " + opponent.getHealth());
    }

    @Override
    public void defend() {
        int increasedDefense = getDefense() + 5; // Example of increasing defense temporarily
        setDefense(increasedDefense);
        System.out.println("Mage " + getName() + " casts a shield! Defense increased to: " + increasedDefense);
    }

    public int getMagicPower() {
        return magicPower;
    }

    public void setMagicPower(int magicPower) {
        this.magicPower = magicPower;
    }
}
