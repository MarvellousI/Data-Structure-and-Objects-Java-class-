package weekTen.labTen;

public class Warrior extends Character implements Fighter {
    public Warrior(int health, int attackPower, int defense, String name) {
        super(health, attackPower, defense, name);
    }

    @Override
    public void attack(Character opponent) {
        int damage = getAttackPower() - opponent.getDefense();
        opponent.setHealth(opponent.getHealth() - (damage > 0 ? damage : 0));
        System.out.println("Warrior " + getName() + " attacks! Opponent's health: " + opponent.getHealth());
    }

    @Override
    public void defend() {
        int increasedDefense = getDefense() + 5; // Example of increasing defense temporarily
        setDefense(increasedDefense);
        System.out.println("Warrior " + getName() + " defends! Defense increased to: " + increasedDefense);
    }
}
