package weekTen.labTen;

public class Archer extends Character implements Fighter {
    public Archer(int health, int attackPower, int defense, String name) {
        super(health, attackPower, defense, name);
    }

    @Override
    public void attack(Character opponent) {
        int damage = getAttackPower() - opponent.getDefense();
        opponent.setHealth(opponent.getHealth() - (damage > 0 ? damage : 0));
        System.out.println("Archer " + getName() + " shoots an arrow! Opponent's health: " + opponent.getHealth());
    }

    @Override
    public void defend() {
        int increasedDefense = getDefense() + 5; // Example of increasing defense temporarily
        setDefense(increasedDefense);
        System.out.println("Archer " + getName() + " dodges! Defense increased to: " + increasedDefense);
    }
}
