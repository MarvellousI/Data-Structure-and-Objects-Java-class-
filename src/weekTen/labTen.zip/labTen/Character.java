package weekTen.labTen;

public abstract class Character {
    private int health;
    private int attackPower;
    private int defense;
    private String getName;

    public Character(int health, int attackPower, int defense) {
        this.health = health;
        this.attackPower = attackPower;
        this.defense = defense;
        this.getName = getName;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAttackPower() {
        return attackPower;
    }

    public void setAttackPower(int attackPower) {
        this.attackPower = attackPower;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }
    public String setGetName(){
        return getName;
    }

    public abstract void attack(Character opponent);

}
