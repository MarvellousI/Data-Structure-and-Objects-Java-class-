package weekTen.labTen;

public interface Fighter {
    void attack(Character opponent);
}
