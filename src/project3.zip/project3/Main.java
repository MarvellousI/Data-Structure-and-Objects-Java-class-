package project3;

public class Main {
    public static void main(String[] args) {
        // Create an instance of the Menu class
        Menu menu = new Menu();

        // Call the runMenu() method to start the program
        menu.runMenu();
    }
}

