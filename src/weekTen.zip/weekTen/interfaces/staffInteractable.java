package weekTen.interfaces;

public class staffInteractable implements Interactable {
    @Override
    public void interact() {
        System.out.println("Staff is managing tables and handling orders.");
    }

}
