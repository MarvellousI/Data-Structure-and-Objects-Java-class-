package weekFourteen.Activity29;

public class BigOTest {
    public static void main(String[] args) {
        BigO x = new BigO();
        x.printNSquarredTimes(4);
        x.printNTimes(3);
    }
}
